package edu.udel.blc.semantic_analysis.type

object BooleanType : Type {
    override fun toString(): String = "Boolean"
}