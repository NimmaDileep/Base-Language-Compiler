package edu.udel.blc.ast


class UnitLiteralNode(
    range: IntRange,
) : ExpressionNode(range)