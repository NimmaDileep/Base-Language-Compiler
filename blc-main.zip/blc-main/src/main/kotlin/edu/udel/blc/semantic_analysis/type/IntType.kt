package edu.udel.blc.semantic_analysis.type

object IntType : Type {
    override fun toString(): String = "Int"
}