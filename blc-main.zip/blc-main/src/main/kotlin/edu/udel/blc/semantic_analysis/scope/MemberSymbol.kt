package edu.udel.blc.semantic_analysis.scope


interface MemberSymbol : Symbol