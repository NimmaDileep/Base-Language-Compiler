package edu.udel.blc.semantic_analysis.type

object UnknownType : Type {
    override fun toString() = "Unknown"
}