package edu.udel.blc.semantic_analysis.type

object UnitType : Type {
    override fun toString(): String = "Unit"
}