package edu.udel.blc.ast

class SelfNode(
    range: IntRange
) : ExpressionNode(range)