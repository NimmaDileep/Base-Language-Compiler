package edu.udel.blc.semantic_analysis.type

object StringType : Type {
    override fun toString() = "String"
}