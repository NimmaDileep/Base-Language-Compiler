package edu.udel.blc.semantic_analysis.type

object AnyType : Type {
    override fun toString(): String = "Any"
}