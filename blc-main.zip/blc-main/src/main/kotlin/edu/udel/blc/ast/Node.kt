package edu.udel.blc.ast


abstract class Node(
    val range: IntRange,
)