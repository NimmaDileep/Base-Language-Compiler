package edu.udel.blc.semantic_analysis.scope


sealed interface TypeSymbol : Symbol
