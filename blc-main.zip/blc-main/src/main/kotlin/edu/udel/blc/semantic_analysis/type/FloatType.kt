package edu.udel.blc.semantic_analysis.type

object FloatType: Type{
    override fun toString(): String = "Float"
}